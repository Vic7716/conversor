package procesos;

public class ExceptionProceso extends Exception {
	public ExceptionProceso(String mensaje) {
        super(mensaje);
    }
}
